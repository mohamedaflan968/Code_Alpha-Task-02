const display = document.getElementById('display');
const buttons = Array.from(document.getElementsByClassName('btn'));

buttons.map(button => {
    button.addEventListener('click', (e) => {
        switch(e.target.id) {
            case 'clear':
                display.innerText = '0';
                break;
            case 'backspace':
                if (display.innerText) {
                    display.innerText = display.innerText.slice(0, -1);
                }
                break;
            case 'equals':
                try {
                    display.innerText = eval(display.innerText.replace('÷', '/').replace('×', '*'));
                } catch {
                    display.innerText = 'Error';
                }
                break;
            case 'sqrt':
                display.innerText = Math.sqrt(eval(display.innerText));
                break;
            case 'square':
                display.innerText = Math.pow(eval(display.innerText), 2);
                break;
            case 'sin':
                display.innerText = Math.sin(eval(display.innerText));
                break;
            case 'cos':
                display.innerText = Math.cos(eval(display.innerText));
                break;
            case 'tan':
                display.innerText = Math.tan(eval(display.innerText));
                break;
            default:
                if (display.innerText === '0') {
                    display.innerText = e.target.innerText;
                } else {
                    display.innerText += e.target.innerText;
                }
        }
    });
});
